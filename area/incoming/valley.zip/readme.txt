
			http://www.chainsmokingdryad.com

	Thanks for visiting Mish's Tree, and downloading an area. Full permission is granted to use this area on any ROM 2.4 MUD, provided that I am given credit for the original area file in a visible area listing on the MUD. You may alter the area as needed. You may not reproduce this area file on any other websites without my express written permission.

	Thanks again, and let me know if you find the area to be of use :)


- Mish (mish@chainsmokingdryad.com)