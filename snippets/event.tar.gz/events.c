events...

Events according to Kyndig...

This may or may not be everything. I've tried to give all
functions and examples of use, but if you sue me cause it aint
right, I'm broke so you aint gonna get nothing. Not including
MSP sound events. Providing brief example functions. I hope this
is everything. If something goes wrong,  I will be glad to look
through my source files to help you out.

The credit for this code goes to Kyndig @ www.kyndig.com. He is
the mastermind. Blame him for how great it works. All I have done
is use it.

Original by: Kyndig@kyndig.com
on the most excellent Kyndig.com server: titan.kymdig.com
on which YOU should be hosting your MUD, too!

aww.h - merc.h - mud.h
typedef struct  event_data          EVENT_DATA;  /* timed events */
#define PULSE_EVENT            ( 2 * PULSE_PER_SECOND)

/* timed events from kyndig.com */
struct event_data
{
   int        delay;
   CHAR_DATA    *to;
   int       action;
   DO_FUN   *do_fun;
   char    *args[5];
   void    *argv[5];
   int      argi[5];
   EVENT_DATA *next;
   bool       valid;
};

extern EVENT_DATA *events;

/* timed event action */
#define ACTION_PRINT      1
#define ACTION_FUNCTION   2
#define ACTION_WAIT       3
#define ACTION_ACT        4

/* timer.c */
char *   nsprintf       args( (char *, char *, ...) );
void  wait_wait         args( (CHAR_DATA *, int, int) );
void  wait_printf       args( (CHAR_DATA *, int, char *, ...) );
void  wait_act          args( (int, char *, void *, void *, void *, int) );
void  wait_function     args( (CHAR_DATA *ch,int delay, DO_FUN *do_fun, char *argument) );
EVENT_DATA *create_event(int, char *);

/* recycle.c */
/* stuff for recycling timed events */
EVENT_DATA *ev_free;

EVENT_DATA *new_event(void)
{
    static EVENT_DATA ev_zero;
    EVENT_DATA *ev;

    if ( ev_free == NULL )
       ev = alloc_perm(sizeof(*ev));
    else
    {
	ev = ev_free;
	ev_free = ev_free->next;
    }

    *ev = ev_zero;
    VALIDATE(ev);
    ev->to   = NULL;
    return ev;
}

void free_event(EVENT_DATA *ev)
{
    if (!IS_VALID(ev))
	return;

    INVALIDATE(ev);

    ev->next = ev_free;
    ev_free = ev;
}

/* recycle.h */

/* timed event recycling */
#define ED EVENT_DATA
ED *new_event args( (void) );
void free_event args( (ED *ev) );
#undef ED

/*******************************************************************************
 *                 ROM Version 2.4 beta                                        *
 *      Original DikuMUD by Hans Staerfeldt, Katja Nyboe,                      *
 *      Tom Madsen, Michael Seifert, and Sebastian Hammer                      *
 *      Based on MERC 2.1 code by Hatchet, Furey, and Kahn                     *
 *      ROM 2.4 copyright (c) 1993-1996 Russ Taylor                            *
 *                                                                             *
 * ___  _  _ _  _ ____ ____ ____ _  _    ____ _  _ _  _ _  _ ____ ____ ____    *
 * |  \ |  | |\ | | __ |___ |  | |\ |    |__/ |  | |\ | |\ | |___ |__/ [__     *
 * |__/ |__| | \| |__] |___ |__| | \|    |  \ |__| | \| | \| |___ |  \ ___]    *
 *              kyncode version: 3b.99  (not yet released)                     *
 *******************************************************************************/
/* Minor modifications made by Dalsor to make more WoT-like */

#if defined(macintosh)
#include <types.h>
#else
#include <sys/types.h>
#include <sys/time.h>
#endif

#include <ctype.h>
#include <errno.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <time.h>
#include <unistd.h>
#include <stdarg.h>

#include "aww.h"
#include "recycle.h"

char *nsprintf(char *fr, char *fmt, ...)
{
        char buf[2*MSL];
        va_list args;

        va_start(args, fmt);
        vsprintf(buf, fmt, args);
        va_end(args);

        free_string(fr);
        return str_dup(buf);
}

EVENT_DATA *create_event(int delay, char *act)
{
        EVENT_DATA *ev;

        if(!str_cmp(act, "print"))
        {
                ev=new_event();
                ev->action=ACTION_PRINT;
        } else if(!str_cmp(act, "wait"))
        {
                ev=new_event();
                ev->action=ACTION_WAIT;
        } else if(!str_cmp(act, "act"))
        {
                ev=new_event();
                ev->action=ACTION_ACT;
        } else if(!str_cmp(act, "function"))
        {       ev=new_event();
                ev->action=ACTION_FUNCTION;
        }
        else { /* Bad Action */
                return NULL;
        }
        ev->delay= delay;
        ev->next = events;
        events   = ev;
        return ev;
}

/* send an 'act' sequence to target after delay has been met */
void wait_act(int delay, char *msg, void *a1, void *a2, void *a3, int type)
{
        EVENT_DATA *ev=create_event(delay, "act");
        ev->args[0]=str_dup(msg);
        ev->argv[0]=a1;
        ev->argv[1]=a2;
        ev->argv[2]=a3;
        ev->argi[0]=type;
        return;
}

/* send a delayed FORMATED string to target ( Uses printf_ function ) */
void wait_printf(CHAR_DATA *ch, int delay, char * fmt, ...)
{
        char buf[2*MSL];
        va_list args;
        EVENT_DATA *ev = create_event(delay, "print");

        va_start(args, fmt);
        vsprintf(buf, fmt, args);
        va_end(args);

        ev->args[0] = str_dup(buf);
        ev->argv[0] = ch;
        return;
}

/* after the delay has been met..it will freeze
 * the targeted victim for the set amount of 'dur'ation
 * ex:  wait_wait(ch,2,5); would:
 * cause player who triggered this call to be frozen
 * for 5 seconds after 2 seconds of function call
 * good for mprogs
 */
void wait_wait(CHAR_DATA *ch, int delay, int dur)
{
        EVENT_DATA *ev = create_event( delay, "wait");

        ev->argv[0] = ch;
        ev->argi[0] = dur;
}

/* call the specified function after delay has been met */
void wait_function (CHAR_DATA *ch, int delay, DO_FUN *do_fun, char *argument)
{
   EVENT_DATA *ev = create_event( delay, "function" );

   ev->argv[0] = ch;
   ev->do_fun  = do_fun;
   ev->args[0] = str_dup( argument );
   return;
}

/* update.c */

void free_event args( (EVENT_DATA *ev) );
EVENT_DATA	*events;

#define kill_event \
				if(!ev_next)  {   free_event(ev); return; }  \
				if(ev_last!=NULL) ev_last->next=ev_next;  \
				             else events=ev_next;  \
				free_event(ev);  \
				continue;

/*
 * Handle events.
 */
void event_update(void)
{
   EVENT_DATA *ev = NULL, *ev_next, *ev_last = ev;


   if(!events) return;

   for( ev = events; ev; ev = ev_next)
   {
        ev_next = ev->next;
        if(ev->delay-- <= 0)
        {
            switch(ev->action)
            {
                case ACTION_PRINT:
                  if( ( !ev->args[0]) || (! ev->argv[0] ) )
                  {
                      kill_event
                  }
                  stc( ev->args[0], ev->argv[0] );
                  break;

                case ACTION_FUNCTION:
                  if( !ev->args[0] )
                  {
                      kill_event
                  }
                  do_function(ev->argv[0], ev->do_fun, ev->args[0]);
                  break;

                case ACTION_WAIT:
                  if(!ev->argv[0])
                  {
                      kill_event
                  }
                  WAIT_STATE(ev->to,PULSE_PER_SECOND*ev->argi[0]);
                  break;

                case ACTION_ACT:
                  if(!ev->args[0] || !ev->argv[0])
                  {
                       kill_event
                  }
                  act(ev->args[0], ev->argv[0], ev->argv[1],ev->argv[2],ev->argi[0]);
                  break;
            }

            if(!ev_next)
            {
                 if( (ev != events) && (ev_last != NULL) )
                 {
                      if( ev_last->next == ev )
                         ev_last->next=NULL;
                 }
                 else
                 {
                 if( ev == events)
                    events = NULL;
                 }
                 free_event( ev );
                 return;
            }

            if( ev_last != NULL)
                ev_last->next = ev_next;
            else
                events = ev_next;

            free_event( ev );
            continue;
        } /* end delay */

        ev_last = ev;

   } /* end loop */
return;
}
