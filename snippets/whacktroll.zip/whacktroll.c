/***************************************************************************
 * You may use this code as you see fit within any non-commercial MUD.     *
 * My only conditions are that my comments remain in tact, that you do not *
 * hesitate to give me feedback on the code, that my name remains in the   *
 * whack-a-troll helpfile, and that you don't claim my work as your own.   *
 *                                                      Enjoy.  -- Midboss *
 * *********************************************************************** *
 * Whack-a-Troll minigame.  Players are taken to a 3x3 arena where 'troll' *
 * mobs randomly pop up.  When a player kills one of these trolls, they    *
 * recieve 'troll points' equal to its level.  The player with the most    *
 * points after 2 minutes wins.                                            *
 ***************************************************************************/
#include <stdio.h>
#include "merc.h"
#include "interp.h"

int whack_state;
int whack_counter;
int whack_timer;

/*
 * Loads a random troll (or trolls) in a random spot (or spots).
 */
void pop_troll (void)
{
	ROOM_INDEX_DATA * pRoom;
	MOB_INDEX_DATA * pMobIndex;
	CHAR_DATA * troll;
	int pop[3][2];
	int i, vnum;

	/*
	 * Fill the slots.
	 */
	for (i = 0; i < 2; i++)
	{
		/*
		 * Go through whack-a-troll vnums...
		 */
		for (vnum = 29976; vnum < 30000; vnum++)
		{
			/*
			 * See if we've got one.
			 */
			pMobIndex = get_mob_index (vnum);
			
			if (pMobIndex != NULL && number_percent() < 30)
			{
				pop[i][0] = vnum;
				pop[i][1] = number_range (29976, 29984);
			}
		}
	}

	/*
	 * Now load the trolls.
	 */
	for (i = 0; i < 3; i++)
	{
		if ((pMobIndex = get_mob_index (pop[i][0])) == NULL)
			continue;
		if ((pRoom = get_room_index (pop[i][1])) == NULL)
			continue;

	    troll = create_mobile (pMobIndex);
		char_to_room (troll, pRoom);
		SET_BIT(troll->act, ACT_IS_TROLL);
	    act ("$n pops out of a hole in the ground!",
				troll, NULL, NULL, TO_ROOM);
	}
}

/*
 * Distributes prizes for the winners of Whack-a-Troll.  I've only made it
 * distribute a tiny amount of gold, but you can get as creative with it as
 * you want.
 */
void troll_prizes (CHAR_DATA * first, CHAR_DATA * second)
{
	int gold[2] = {500, 150};

	printf_to_char (first, "[Troll] You recieved %d gold.\n\r", gold[0]);
	first->gold += gold[0];

	printf_to_char (second, "[Troll] You recieved %d gold.\n\r", gold[1]);
	second->gold += gold[1];
	return;
}

/*
 * Update function for the Whack-a-Troll minigame.
 */
void whack_a_troll (void)
{
    if (--whack_timer <= 0)
    {
		ROOM_INDEX_DATA * pRoom;
		CHAR_DATA * sch, * sch_next, * ch1 = NULL, * ch2 = NULL;
		int vnum, pcount = 0;
		DESCRIPTOR_DATA *d;

		/*
		 * Update every 10 seconds while playing, every minute between
		 * games of Whack-a-Troll.
		 */
		if (whack_state == 0)
			whack_timer = PULSE_PER_SECOND * 60;
		else
			whack_timer = PULSE_PER_SECOND * 10;

		++whack_counter;

		switch (whack_state)
		{
			/*
			 * Pregame.
			 */
			case 0:
				/*
				 * No minutes left?  Start the game!
				 */
				if (whack_counter == 5)
				{
					/*
					 * Count the players.
					 */
					for (vnum = 29976; vnum < 29985; vnum++)
					{
						pRoom = get_room_index (vnum);
						
						for (sch = pRoom->people; sch != NULL;
								sch = sch_next)
						{
							sch_next = sch->next_in_room;
							if (!IS_NPC (sch))
								++pcount;
						}
					}

					/*
					 * Not enough players?
					 */
					if (pcount < 2)
					{
						/*
						 * Reset the minutes.
						 */
						whack_counter = 0;

						/*
						 * Notify everyone it was cancelled.
						 */
						for (d = descriptor_list; d != NULL; d = d->next)
						{
							sch = d->original ? d->original : d->character;

							if (d->connected == CON_PLAYING &&
								!IS_SET (sch->comm, COMM_NOTROLL) &&
								!IS_SET (sch->comm, COMM_QUIET))
								printf_to_char (sch, "[Troll] There"
									" weren't enough players for "
									"a game of Whack-a-Troll...\n\r");
						}

						/*
						 * Take everyone out of the arena.
						 */
						for (vnum = 29976; vnum < 29985; vnum++)
						{
							pRoom = get_room_index (vnum);
							
							for (sch = pRoom->people; sch != NULL;
									sch = sch_next)
							{
								sch_next = sch->next_in_room;
								if (!IS_NPC (sch) && sch->was_in_room != NULL)
								{
									sch->pcdata->trollpoints = 0;
									char_from_room (sch);
									char_to_room (sch, sch->was_in_room);
									do_function (sch, &do_look, "auto");
								}
								else if (IS_NPC (sch))
									extract_char (sch, TRUE);
							}
						}
						break;
					}

					/*
					 * Reset all this stuff.
					 */
					whack_counter = 0;
					whack_state = 1;
					whack_timer = PULSE_PER_SECOND * 10;
					pop_troll();

					/*
					 * Notify everyone the game has begun.
					 */
					for (d = descriptor_list; d != NULL; d = d->next)
					{
						sch = d->original ? d->original : d->character;

						if (d->connected == CON_PLAYING &&
							!IS_SET (sch->comm, COMM_NOTROLL) &&
							!IS_SET (sch->comm, COMM_QUIET))
							printf_to_char (sch,
								"[Troll] A new game of Whack-a-Troll has"
								" begun!\n\r");
					}
					break;
				}
				/*
				 * Still waiting.
				 */
				else
				{
					/*
					 * Count the players.
					 */
					for (vnum = 29976; vnum < 29985; vnum++)
					{
						pRoom = get_room_index (vnum);
						
						for (sch = pRoom->people; sch != NULL;
								sch = sch_next)
						{
							sch_next = sch->next_in_room;
							if (!IS_NPC (sch))
								++pcount;
						}
					}

					/*
					 * Echo how many people we've got, and how much time is
					 * left until the next game starts.
					 */
					for (d = descriptor_list; d != NULL; d = d->next)
					{

						sch = d->original ? d->original : d->character;

						if (d->connected == CON_PLAYING &&
							!IS_SET (sch->comm, COMM_NOTROLL) &&
							!IS_SET (sch->comm, COMM_QUIET))
							printf_to_char (sch, "[Troll] A new game of"
								" Whack-a-Troll begins in %d minutes.\n\r"
								"[Troll] There %s currently %d"
								" player%s.\n\r", 5-whack_counter,
									pcount == 1 ? "is" : "are",
									pcount,
									pcount == 1 ? "" : "s");

					}
					break;
				}
				break;
			case 1:
				/*
				 * Find the two leaders.
				 */
				for (vnum = 29976; vnum < 29985; vnum++)
				{
					pRoom = get_room_index (vnum);
					
					for (sch = pRoom->people; sch != NULL;
							sch = sch_next)
					{
						
						sch_next = sch->next_in_room;
						if (!IS_NPC (sch))
						{
							/*
							 * Is this guy winning?
							 */
							if (ch1 == NULL
								|| sch->pcdata->trollpoints >
									ch1->pcdata->trollpoints)
							{
								if (ch1 != NULL)
									ch2 = ch1;

								ch1 = sch;
							}
							/*
							 * Well, is he at least in second?
							 */
							else if (ch2 == NULL
								|| sch->pcdata->trollpoints >
									ch2->pcdata->trollpoints)
								ch2 = sch;
						}
					}
				}

				/*
				 * Has something gone wrong?
				 */
				if (ch1 == NULL || ch2 == NULL)
				{
					/*
					 * Notify everyone it was cancelled.
					 */
					for (d = descriptor_list; d != NULL; d = d->next)
					{
						sch = d->original ? d->original : d->character;

						if (d->connected == CON_PLAYING &&
							!IS_SET (sch->comm, COMM_NOTROLL) &&
							!IS_SET (sch->comm, COMM_QUIET))
							printf_to_char (sch, "[Troll] There "
								"weren't enough players to continue the "
								"game of Whack-a-Troll...\n\r");
					}

					/*
					 * Take everyone out of the arena.
					 */
					for (vnum = 29976; vnum < 29985; vnum++)
					{
						pRoom = get_room_index (vnum);
						
						for (sch = pRoom->people; sch != NULL;
								sch = sch_next)
						{
							sch_next = sch->next_in_room;
							if (!IS_NPC (sch) && sch->was_in_room != NULL)
							{
								sch->pcdata->trollpoints = 0;
								char_from_room (sch);
								char_to_room (sch, sch->was_in_room);
								do_function (sch, &do_look, "auto");
							}
							else if (IS_NPC (sch))
								extract_char (sch, TRUE);
						}
					}

					whack_counter = 0;
					whack_state = 0;
					whack_timer = PULSE_PER_SECOND * 60;
					break;
				}

				/*
				 * 2 minutes sounds good.
				 */
				if (whack_counter == 12)
				{
					/*
					 * Echo the ending.
					 */
					for (d = descriptor_list; d != NULL; d = d->next)
					{
						sch = d->original ? d->original : d->character;

						if (d->connected == CON_PLAYING &&
							!IS_SET (sch->comm, COMM_NOTROLL) &&
							!IS_SET (sch->comm, COMM_QUIET))
							printf_to_char (sch,
								"[Troll] %s has won the game of"
								" Whack-a-Troll, with %d points.\n\r"
								"[Troll] %s takes second place with %d"
								" points.\n\r", ch1->name,
								ch1->pcdata->trollpoints,
								ch2->name, ch2->pcdata->trollpoints);

					}

					/*
					 * Take everyone out of the arena.
					 */
					for (vnum = 29976; vnum < 29985; vnum++)
					{
						pRoom = get_room_index (vnum);
						
						for (sch = pRoom->people; sch != NULL;
								sch = sch_next)
						{
							sch_next = sch->next_in_room;
							if (!IS_NPC (sch) && sch->was_in_room != NULL)
							{
								sch->pcdata->trollpoints = 0;
								char_from_room (sch);
								char_to_room (sch, sch->was_in_room);
								do_function (sch, &do_look, "auto");
							}
							else if (IS_NPC (sch))
								extract_char (sch, TRUE);
						}
					}

					troll_prizes (ch1, ch2);
					whack_counter = 0;
					whack_state = 0;
					whack_timer = PULSE_PER_SECOND * 60;
				}
				else
				{

					/*
					 * Echo how many people we've got, and how much time is
					 * left until the next game starts.
					 */
					for (d = descriptor_list; d != NULL; d = d->next)
					{
						sch = d->original ? d->original : d->character;

						if (d->connected == CON_PLAYING &&
							!IS_SET (sch->comm, COMM_NOTROLL) &&
							!IS_SET (sch->comm, COMM_QUIET))
							printf_to_char (sch,
								"[Troll] %s is in the lead, with %d "
								"points.\n\r[Troll] %s is followed by"
								" %s, with %d points.\n\r",
								ch1->name, ch1->pcdata->trollpoints,
								ch1->sex == SEX_FEMALE ? "She" : 
								ch1->sex == SEX_MALE ? "He" :"It",
								ch2->name, ch2->pcdata->trollpoints);
					}

					/*
					 * Load some trolls!
					 */
					pop_troll();
				}
				break;
		}
    }
}


/*
 * The whack-a-troll command.  Acts as a channel.  No argument toggles the
 * Whack-a-Troll channel on or off, 'info' displays what's going on with the
 * minigame, and 'join' will enter the game if possible.
 */
void do_troll (CHAR_DATA * ch, char * argument)
{

	ROOM_INDEX_DATA * pRoom;
	CHAR_DATA * sch, * sch_next, * ch1 = NULL, * ch2 = NULL;
	int vnum, pcount = 0;
	DESCRIPTOR_DATA *d;
	

	if (!str_cmp (argument, "info"))
	{
		switch (whack_state)
		{
			case 0:
				/*
				 * Count the players.
				 */
				for (vnum = 29976; vnum < 29985; vnum++)
				{
					pRoom = get_room_index (vnum);
					
					for (sch = pRoom->people; sch != NULL; sch = sch_next)
					{
						sch_next = sch->next_in_room;
						if (!IS_NPC (sch))
							++pcount;
					}
				}

				/*
				 * Show the stats.
				 */
				printf_to_char (ch, "There %s %d minute%s until the"
								" next game.\n\r%d player%s %s entered so "
								"far.\n\r",
								5-whack_counter == 1 ? "is" : "are",
								5-whack_counter,
								5-whack_counter == 1 ? "" : "s",
								pcount, pcount == 1 ? "" : "s",
								pcount == 1 ? "has" : "have");
				break;
			case 1:
				/*
				 * Count the players.
				 */
				for (vnum = 29976; vnum < 29985; vnum++)
				{
					pRoom = get_room_index (vnum);
					
					for (sch = pRoom->people; sch != NULL; sch = sch_next)
					{
						sch_next = sch->next_in_room;
						if (!IS_NPC (sch))
							++pcount;
					}
				}

				/*
				 * Find the two leaders.
				 */
				for (vnum = 29976; vnum < 29985; vnum++)
				{
					pRoom = get_room_index (vnum);
					
					for (sch = pRoom->people; sch != NULL;
							sch = sch_next)
					{
						
						sch_next = sch->next_in_room;
						if (!IS_NPC (sch))
						{
							/*
							 * Is this guy winning?
							 */
							if (ch1 == NULL
								|| sch->pcdata->trollpoints >
									ch1->pcdata->trollpoints)
							{
								if (ch1 != NULL)
									ch2 = ch1;

								ch1 = sch;
							}
							/*
							 * Well, is he at least in second?
							 */
							else if (ch2 == NULL
								|| sch->pcdata->trollpoints >
									ch2->pcdata->trollpoints)
								ch2 = sch;
						}
					}
				}

				/*
				 * Show the stats.
				 */
				printf_to_char (ch, "The game has already started.\n\r"
								"%d player%s %s entered.\n\r",
								pcount, pcount == 1 ? "" : "s",
								pcount == 1 ? "is" : "are");

				if (ch1 != NULL)
				{
					printf_to_char (ch,
						"%s %s in the lead with %d points.\n\r",
								ch1 == ch ? "You" : ch1->name,
								ch1 == ch ? "are" : "is",
								ch1->pcdata->trollpoints);
				}

				if (ch2 != NULL)
				{
					printf_to_char (ch,
						"%s %s in second place with %d points.\n\r",
								ch2 == ch ? "You" : ch2->name,
								ch2 == ch ? "are" : "is",
								ch2->pcdata->trollpoints);
				}
				break;
		}
	}
	else if (!str_cmp (argument, "join"))
	{
		/*
		 * Are we already playing?
		 */
		if (ch->in_room->vnum > 29975 && ch->in_room->vnum < 29985)
		{
			send_to_char ("You're already entered!\n\r", ch);
			return;
		}

		/*
		 * Echo it.
		 */
		for (d = descriptor_list; d != NULL; d = d->next)
		{
			sch = d->original ? d->original : d->character;

			if (d->connected == CON_PLAYING &&
				!IS_SET (sch->comm, COMM_NOTROLL) &&
				!IS_SET (sch->comm, COMM_QUIET))
				printf_to_char (sch,
					"[Troll] %s %s joined the game of Whack-a-Troll.\n\r",
					sch == ch ? "You" : ch->name, sch == ch ? "have" : "has");
		}

		/*
		 * Move them.
		 */
		ch->was_in_room = ch->in_room;
		char_from_room (ch);
		char_to_room (ch, get_room_index (29980));
		do_function (ch, &do_look, "auto");
	}
	else if (!str_cmp (argument, "quit"))
	{
		/*
		 * Are we even playing?
		 */
		if (ch->in_room->vnum < 29976 && ch->in_room->vnum > 29984)
		{
			send_to_char ("You're not entered!\n\r", ch);
			return;
		}


		/*
		 * Can we quit?
		 */
		if (whack_state == 1)
		{
			send_to_char ("You can't quit once the game has started.", ch);
			return;
		}

		/*
		 * Has something gone wrong?
		 */
		if (ch->was_in_room == NULL)
		{
			send_to_char ("You're apparently stuck.  Seek an immortal.", ch);
			return;
		}

		/*
		 * Echo it.
		 */
		for (d = descriptor_list; d != NULL; d = d->next)
		{
			sch = d->original ? d->original : d->character;

			if (d->connected == CON_PLAYING &&
				!IS_SET (sch->comm, COMM_NOTROLL) &&
				!IS_SET (sch->comm, COMM_QUIET))
				printf_to_char (sch,
					"[Troll] %s %s quit the game of Whack-a-Troll.\n\r",
					sch == ch ? "You" : ch->name,
					sch == ch ? "have" : "has");
		}
	
		/* 
		 * Perform.
		 */
		char_from_room (ch);
		char_to_room (ch, ch->was_in_room);
		do_function (ch, &do_look, "auto");
	}
	else
	{
		if (argument[0] == '\0')
		{
			if (IS_SET (ch->comm, COMM_NOTROLL))
			{
				send_to_char ("Whack-a-Troll channel on.\n\r", ch);
				REMOVE_BIT (ch->comm, COMM_NOTROLL);
				return;
			}
			else
			{
				send_to_char ("Whack-a-Troll channel off.\n\r", ch);
				SET_BIT (ch->comm, COMM_NOTROLL);
				return;
			}
		}

        if (IS_SET (ch->comm, COMM_QUIET))
        {
            send_to_char ("You must turn off quiet mode first.\n\r", ch);
            return;
        }

        if (IS_SET (ch->comm, COMM_NOCHANNELS))
        {
            send_to_char
                ("The gods have revoked your channel priviliges.\n\r", ch);
            return;

        }

		/*
		 * Send a message to the channel.
		 */
		for (d = descriptor_list; d != NULL; d = d->next)
		{
			sch = d->original ? d->original : d->character;

			if (d->connected == CON_PLAYING &&
				!IS_SET (sch->comm, COMM_NOTROLL) &&
				!IS_SET (sch->comm, COMM_QUIET))
				printf_to_char (sch, "[Troll] %s: %s\n\r",
					sch == ch ? "You" : ch->name, argument);
		}
	}
	return;
}
